using System.Collections;
using Link;
using UnityEngine;

namespace HoangLinh.Cooking.Test
{
    public class BasketCutItems : ItemMovingBase
    {
        public enum State
        {
            Normal,
            CutBig,
            CutSmall,
            Spice,
            Done
        }

        [SerializeField] State state;
        [SerializeField] Knife knife;

        [SerializeField] private int CUT_BIG = 3;
        [SerializeField] private int CUT_SMALL = 6;

        [SerializeField] GameObject normal, cutBig, cutSmall, spice;

        public override bool IsCanMove => IsState(State.Normal);

        public override bool IsState<T>(T t)
        {
            return state == (State)(object)t;
        }

        public override void ChangeState<T>(T t)
        {
            state = (State)(object)t;
        }

        public override bool OnTake(IItemMoving item)
        {   
            return base.OnTake(item);
        }

        public override void OnClickDown()
        {
            if (IsState(State.CutBig) || IsState(State.CutSmall))
            {
                OrderLayer = 1;
                knife.ChangeAnim("KnifeCutting");
                return;
            }
            base.OnClickDown();
        }

    }
}
